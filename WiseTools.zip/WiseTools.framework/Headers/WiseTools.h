//
//  WiseTools.h
//  WiseTools
//
//  Created by Pavel Joffe on 21/07/2016.
//  Copyright © 2016 WiseSec. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WiseTools/CommonCrypto.h>
#import <WiseTools/sqlite3.h>

//! Project version number for WiseTools.
FOUNDATION_EXPORT double WiseToolsVersionNumber;

//! Project version string for WiseTools.
FOUNDATION_EXPORT const unsigned char WiseToolsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WiseTools/PublicHeader.h>

